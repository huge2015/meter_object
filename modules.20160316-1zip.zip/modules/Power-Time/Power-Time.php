﻿
<?php
$js = JURI::base().'modules/mod_voltage_time/js/jsapi.js';  
$document = JFactory::getDocument($js);  
$document->addScript($js); 

$zh_CN = JURI::base().'modules/mod_voltage_time/js/format+zh_CN,default+zh_CN,ui+zh_CN,corechart+zh_CN.I.js';  
$document2 = JFactory::getDocument($zh_CN);  
$document2->addScript($zh_CN); 

$corechart = JURI::base().'modules/mod_voltage_time/js/corechart.js';  
$document3 = JFactory::getDocument($corechart);  
$document3->addScript($corechart);

$date = JURI::base().'modules/mod_voltage_time/js/date.js';  
$document4 = JFactory::getDocument($date);  
$document4->addScript($date); 

$jq = JURI::base().'modules/mod_voltage_time/js/jquery-1.9.1.js';  
$document5 = JFactory::getDocument($jq);  
$document5->addScript($jq); 
?>


    <!--<script type="text/javascript" src="https://www.google.com/jsapi"></script>-->
    <!--<script type="text/javascript" src="coreChart.js"></script> -->
   <!--script type="text/javascript" src="jsapi.js"></script> 
   <script src="js/corechart.js" type="text/javascript"></script>
   <link href="js/ui+zh_CN.css" type="text/css" rel="stylesheet">
   <script src="js/format+zh_CN,default+zh_CN,ui+zh_CN,corechart+zh_CN.I.js" type="text/javascript"></script>
  <link href="js/tooltip.css" rel="stylesheet" type="text/css"-->

   <script type="text/javascript">
   
   
   var myDate = new Date();
    myDate.getYear();       //获取当前年份(2位)
//alert(myDate.getYear()) //2009
    myDate.getFullYear();   //获取完整的年份(4位,1970-????)
//alert(myDate.getFullYear()); 2009
    myDate.getMonth();      //获取当前月份(0-11,0代表1月)
//alert(myDate.getMonth()); //7(实际是8月)
    myDate.getDate();       //获取当前日(1-31)
//alert( myDate.getDate()); //13
    myDate.getDay();        //获取当前星期X(0-6,0代表星期天)
//alert(myDate.getDay()); //4 代表星期四
    myDate.getTime();       //获取当前时间(从1970.1.1开始的毫秒数)
    myDate.getHours();      //获取当前小时数(0-23)
//alert(myDate.getHours()); //9 代表9点
    myDate.getMinutes();    //获取当前分钟数(0-59)
//alert(myDate.getMinutes()); //45 分
   //var Datesecond = myDate.getSeconds();    //获取当前秒数(0-59)
	
//alert(myDate.getSeconds()); //40 秒数
    myDate.getMilliseconds();   //获取当前毫秒数(0-999)
   var mydate = myDate.toLocaleDateString();    //获取当前日期
    var mytime = myDate.toLocaleTimeString();    //获取当前时间
//alert(mytime);//9:40:18
   var mydatetime = myDate.toLocaleString();       //获取日期与时间
//alert( myDate.toLocaleString( )); //2009年8月13日 9:40:58




    chart = null; // global variable
	chartData = null; // global variable
	chartOptions = null; // global variable
	dataToLoad = ''; // global variable
	chartCol = []; //global variable
	chartCol[0] = {'db_col_name': 'datetime', 'chart_data_type' : 'datetime', 'chart_label' : 'Date Time' };
	datetimeColumnIndex = 0; // global variable
	chartCol[1] = {'db_col_name': 'phase1_voltage', 'chart_data_type' : 'number', 'chart_label' : 'Phase 1 Voltage'};
	chartCol[2] = {'db_col_name': 'phase2_voltage', 'chart_data_type' : 'number', 'chart_label' : 'Phase 2 Voltage'};
	chartCol[3] = {'db_col_name': 'phase3_voltage', 'chart_data_type' : 'number', 'chart_label' : 'Phase 3 Voltage'};
	vChartAxisMinValue = 0; // global
	vChartAxisMaxValue = 60; // global

	dbColumns = ''; //global variable
	var first_time = 1;
	for (var k = 0; k < chartCol.length; k++){
		if (first_time) { first_time = 0;} else { dbColumns += ',';}
		dbColumns = dbColumns + chartCol[k]['db_col_name'];
	} // for k

	dbTable = 'electrical'; // global variable
	lastRowIndex = 0; // global
	timeRefresh = 15000; // global, refreshes every 15 s
	refreshPeriod = '1-i'; // global, the case to call in changeHAxis
	removeTime = 180000; // global, time in seconds before current time to remove the data
   
   
   
   
    // Load the Visualization API and the piechart package.------------------------------------------------------
	google.load('visualization', '1.0', {'packages':['corechart']});

	// Set a callback to run when the Google Visualization API is loaded.
	google.setOnLoadCallback(drawChart);

	// Callback that creates and populates a data table, 
	// instantiates the pie chart, passes in the data and
	// draws it.
	
	
    function drawChart() {
        var chartData = new google.visualization.DataTable();
		
        chartData.addColumn('string', 'Task');
        chartData.addColumn('number', 'phase1_voltage');
		chartData.addColumn('number', 'phase2_voltage');
		chartData.addColumn('number', 'phase3_voltage');
		
		// Set chart options
		chartOptions = {'title':'Voltage against Time (Last updated time is ' + Date.now().toString('yyyy-MM-dd HH:mm:ss') + ')',
			'vAxis':{'title':'Voltage (V)', 'minValue':vChartAxisMinValue, 'maxValue':vChartAxisMaxValue},
			'hAxis':{'title':'Time', 'minValue': (5).minutes().ago(), 'maxValue':Date.now()},
			'width':800,
			'height':300};

		var table = dbTable;
		var location_id = '1';
		var meters = '1';
		var columns = dbColumns;
		var from_datetime_string = (1).minutes().ago().toString('yyyy-MM-dd HH:mm:ss');
		var to_datetime_string = Date.now().toString('yyyy-MM-dd HH:mm:ss');
		var num_records = 60;
		var data_interval = '1-s';
		
        chartData.addRows([
          ['T1',    6, 5, 8],
          ['T2',      2, 3, 4],
          ['T3',  3, 2, 5],
          ['T4', 4, 3, 9],
          ['T5',    7, 9, 20],
		  ['T1',    6, 5, 8],
          ['T2',      2, 3, 4],
          ['T3',  3, 2, 5],
          [ mydate, 4, 3, 9],
          [ mytime,    7, 9, 20]
        ]);
        
		/*
		// getChartDataToDataToLoad(table, location_id, meters, columns, from_datetime_string, to_datetime_string, num_records, data_interval);

		// setTimeout( loadDataToChart('new'), 15000);

<?php
			// read electrical status
			$db = JFactory::getDbo();
			$query = $db->getQuery(true);
			//$query->select( $db->quoteName(array('electrical_id', 'location_id', 'datetime', 'phase1_voltage',
			   //'phase1_voltage', 'phase1_current', 'phase1_frequency') ) );
			$query->select('*');   
			$query->from( $db->quoteName('#__electrical') );
			$from_datetime = date('Y-m-d H:i:s', ( time() - 5*60) ); 
			$query->where( $db->quoteName('location_id')." = ".$db->quote(1)  . " AND datetime >= '$from_datetime'  " );
			$query->order('datetime DESC');
			$db->setQuery($query,0,180);
			$rows = $db->loadAssocList();

			sort($rows);

			echo "	lastRowIndex = chartData.addRows([
";
			$firsttime = 0;
			foreach ($rows as $row){
				if (!$firsttime) { $firsttime = 1;}
				else {echo ",
";}
				$phase1_voltage = $row['phase1_voltage'];
				$phase2_voltage = $row['phase2_voltage'];
				$phase3_voltage = $row['phase3_voltage'];
				$datetime = new DateTime($row['datetime']);
				$format_datetime = $datetime->format('Y,m-1,d,H,i,s'); // need to reduce month by 1 as JS month starts from 0
				echo "[ new Date($format_datetime),$phase1_voltage ,$phase2_voltage ,$phase3_voltage ]";
			}// for each
		echo "
]);";
?>
		*/
		
		
		/*
        var chartOptions = {
          width: 650, height: 400,
          title: 'My Daily Activities'
        };
		*/

        var chart = new google.visualization.LineChart(document.getElementById('chart_div'));
        chart.draw(chartData, chartOptions);
      }
    </script>  


<div id="chart_div"></div>
<div id="time_setting">
	Time Frame
	<select name='time_frame' onChange="javascript:changeHAxis(this.value);">>
		<option value="5-y new">5 years</option>
		<option value="2-y new">2 years</option>
		<option value="1-y new">Year</option>
		<option value="1-q new">Quarter</option>
		<option value="1-m new">Month</option>
		<option value="1-w new">Week</option>
		<option value="1-d new">Day</option>
		<option value="1-h new">Hour</option>
		<option value="1-i new" selected>Minute</option>
	</select> 

	<input type=radio name=live_data value='1' checked>Live</input>
	<input type=radio name=live_data value='0'>Historical</input>

</div>

