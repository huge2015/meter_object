﻿<?php
/**
 * @package     electromonitor.com
 * @subpackage  mod_upload_excute
 *
 * @copyright   Copyright (C) 2015 All rights reserved.
 */

defined('_JEXEC') or die;

// Include the functions only once
require_once __DIR__ . '/helper.php';

JHTML::stylesheet('styles.css','modules/mod_upload_excute/css/');

$UploadStatus = ModUploadExcuteHelper::getUploadStatus();
if($UploadStatus == "start"){

$limit = 5; // number of records to Upload

if($queue_id == ""){
	$queue_id = ModUploadExcuteHelper::getQueueId();
	
}

 echo "<br> queue_id : $queue_id <br>";

unset($queue_data);
$queue_data = ModUploadExcuteHelper::getQueueData($queue_id, $limit);

$data_size = count($queue_data);
 //echo "size of data is $data_size <br>";
 
 
 // set up _POST array of key value pairs
$queue_rows = $queue_data;

$n = 0;
//$i = 1;
unset ($_POST);

/*
$num_time = floor($data_size/$limit); // floor(8/5) = floor(1.6) = 1    5/5 = 1   3/5 = 0
$mod_limit = $data_size % $limit;      // 8%5 = 3     5%5 = 0   3%5 = 3

echo "num_time : $num_time <br>";
echo "mod_limit : $mod_limit <br>";
*/

$num_records = $limit;
//$fields = 16;

foreach ($queue_rows AS $data) {

    $electrical_id = $data['electrical_id'];
    $location_id = $data['location_id'];
    $meter_address = $data['meter_address'];
    $datetime = $data['datetime'];
	
	//echo "<br> $electrical_id + $location_id + $meter_address + $datetime";
   
    
	unset($electrical_data);
    $electrical_rows = ModUploadExcuteHelper::getElectricalData($electrical_id, $location_id, $meter_address, $datetime);
	
	
	
    if($electrical_rows != ""){
		
        foreach($electrical_rows AS $electrical_data){
        
		    $_POST["queue_id-$n"]  = $data['queue_id']; //for delete queue data while upload successed
		
		    //echo "<br>electrical_data = $electrical_data[electrical_id] ";
		
            $_POST["controller_electrical_id-$n"]  = $electrical_data['electrical_id'];
            $_POST["location_id-$n"]  = $electrical_data['location_id'];
            $_POST["meter_address-$n"]  = $electrical_data['meter_address'];
            $_POST["datetime-$n"]  = $electrical_data['datetime'];  
   
             $_POST["total_power-$n"]  = $electrical_data['total_power'];
             $_POST["energy_kwh-$n"]  = $electrical_data['energy_kwh'];
             $_POST["phase1_power_factor-$n"]  = $electrical_data['power_factor'];
       
             $_POST["phase1_real_power-$n"]  = $electrical_data['phase1_real_power'];
             $_POST["phase2_real_power-$n"]  = $electrical_data['phase2_real_power'];
             $_POST["phase3_real_power-$n"]  = $electrical_data['phase3_real_power'];
             
            $_POST["phase1_voltage-$n"]  = $electrical_data['phase1_voltage'];
            $_POST["phase1_current-$n"]  = $electrical_data['phase1_current'];
            $_POST["phase1_apparent_power-$n"]  = $electrical_data['phase1_apparent_power'];
            $_POST["phase1_frequency-$n"]  = $electrical_data['phase1_frequency'];
      
            $_POST["phase2_voltage-$n"]  = $electrical_data['phase2_voltage'];
            $_POST["phase2_current-$n"]  = $electrical_data['phase2_current'];
            $_POST["phase2_apparent_power-$n"]  = $electrical_data['phase2_apparent_power'];
            $_POST["phase2_frequency-$n"]  = $electrical_data['phase2_frequency'];
  
            $_POST["phase3_voltage-$n"]  = $electrical_data['phase3_voltage'];
            $_POST["phase3_current-$n"]  = $electrical_data['phase3_current'];
            $_POST["phase3_apparent_power-$n"]  = $electrical_data['phase3_apparent_power'];
            $_POST["phase3_frequency-$n"]  = $electrical_data['phase3_frequency'];
       
            $_POST["Uab-$n"]  = $electrical_data['Uab'];
            $_POST["Ubc-$n"]  = $electrical_data['Ubc'];
            $_POST["Uca-$n"]  = $electrical_data['Uca'];
  
            $_POST["Qa-$n"]  = $electrical_data['Qa'];
            $_POST["Qb-$n"]  = $electrical_data['Qb'];
            $_POST["Qc-$n"]  = $electrical_data['Qc'];
            $_POST["Qs-$n"]  = $electrical_data['Qs'];
  
            $_POST["PFa-$n"]  = $electrical_data['PFa'];
            $_POST["PFb-$n"]  = $electrical_data['PFb'];
            $_POST["PFc-$n"]  = $electrical_data['PFc'];
            $_POST["PFs-$n"]  = $electrical_data['PFs'];
  
            $_POST["Sa-$n"]  = $electrical_data['Sa'];
            $_POST["Sb-$n"]  = $electrical_data['Sb'];
            $_POST["Sc-$n"]  = $electrical_data['Sc'];
            $_POST["Ss-$n"]  = $electrical_data['Ss'];
  
            $_POST["WPP-$n"]  = $electrical_data['WPP'];
            $_POST["WPN-$n"]  = $electrical_data['WPN'];
            $_POST["WQP-$n"]  = $electrical_data['WQP'];
            $_POST["WQN-$n"]  = $electrical_data['WQN'];
  
            $_POST["EPN-$n"]  = $electrical_data['EPN'];
            $_POST["EQP-$n"]  = $electrical_data['EQP'];
            $_POST["EQN-$n"]  = $electrical_data['EQN'];
		
        }//foreach($electrical_rows AS $electrical_data)
		
	}else{
		
		echo "electrical_data == null ";
		
	}//if($electrical_rows != "")
    
	
  $n++;
  //$i++;
   //echo "n= $n ...";

} //foreach


    @$fields = sizeof($_POST)/$n;
    //echo "<br>fields : $fields ";
  
    //echo "<br>".json_encode($_POST);
  
  //queue_dequeue($myqueue); // Removed the element at the front of the queue
  //$peek = queue_peek($myqueue); //Front element of the queue
  //echo '<p>Front of the queue is: ', var_dump($peek), '</p>';   
  //echo var_dump($myqueue);
  //echo json_encode($peek);

 
?>
<div id="setTimejump" algin=center></div>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<!--script src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script-->
<script type="text/javascript">

function uploaddata(){
	//alert(" inside getpushdata");
	   
       var post = '<?php echo json_encode($_POST);?>';
	   var data_pos = '<?php echo $data_pos ;?> ';
	   var time_pos = '<?php echo $time_pos ;?> ';
	   
		jQuery.ajax({
			//type : "get",
            //async : false,
			//cache:false,
			//crossdomain: true,
			url: "index.php",
			//url: "http://192.168.0.201/joomla/index.php",
			//url: "http://www.electromonitor.com/monitor/index.php",
			
			//dataType:'jsonp',  //return type  
			jsonp: "callbackparam",    //send / revice param default is "callback"
            jsonpCallback:"jsonpCallback",
            timeout:5000,
			data: {"option":"com_ajax", "module":"uploaddata", "method":"getUploadData","format":"jsonp", 
			       "allarr" : post,
		           "num_records" : "<?php echo $limit;?>",
		           "fields" : "<?php echo $fields;?>"
		    },
            success: function(){
				
				'<?php ModUploadExcuteHelper::delQueueData($_POST, $limit); ?>'
				
				alert('Success!');
				//location.href="index.php/updata-pos?data_pos="+data_pos+"&time_pos="+time_pos;
             },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
				         //result = JSON.stringify(XMLHttpRequest);
						 callText = XMLHttpRequest.statusText;
				       //alert('XMLHttpRequest : '+returnText);
						//alert('XMLHttpRequest : '+callText);
                        //alert('status : '+XMLHttpRequest.status);
                        //alert('readyState : '+ XMLHttpRequest.readyState);
                        //alert('textStatus : '+textStatus);
						//alert('errorThrown : '+XMLHttpRequest.errorThrown);
						
						if(callText == "success"){
							alert('error -> Success!');
							//location.href="index.php/updata-pos?data_pos="+data_pos+"&time_pos="+time_pos;
						}else{
							//location.href="index.php/updata-error?&try_time=<?php echo $try_time;?>&error_msg="+callText;
						}
            },
            complete: function(XMLHttpRequest, textStatus) {
                         // call this time AJAX request options params
            }
        });
}			


//uploaddata()  //Run Ajax functon uploadata()

</script>

<?php 
echo ("<script type=\"text/javascript\">");
echo ("uploaddata()");      
echo ("</script>");



require(JModuleHelper::getLayoutPath('mod_upload_excute', 'default'));


//sleep(3);
//$lines = file("http://localhost/joomla/index.php/upload-excute");


}else{
	echo "<br><br><br><br><H1>请先开启上传数据开关！</H1><br><br><br><br>";
}//if($UploadStatus == "1")
?>