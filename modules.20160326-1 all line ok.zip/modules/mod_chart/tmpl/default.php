<?php defined('_JEXEC') or die;

/**
 * File       default.php
 */
defined('_JEXEC') or die;
?>

<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
</head>


<div>
	<h1>MOD CHART</h1>
	<?php echo "From default file"; ?>
</div>