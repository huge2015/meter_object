﻿<?php
/**
 * @package     electromonitor.com
 * @subpackage  mod_upload_local
 *
 * @copyright   Copyright (C) 2015 All rights reserved.
 */

header('Content-type: text/html; charset=utf8');
defined('_JEXEC') or die;

// Include the functions only once
require_once __DIR__ . '/helper.php';

JHTML::stylesheet('styles.css','modules/mod_dianbiao_submit/css/');

$location_id = trim(JRequest::getVar('location_id', '1')); 
$expression = trim(JRequest::getVar('expression', '1-i new')); 
$live_data = trim(JRequest::getVar('live_data', '1'));

    $db = JFactory::getDbo();
	$query = $db->getQuery(true);
	$query->select( $db->quoteName(array('info_id', 'location_id', 'meter_address') ) ); 
	$query->from( $db->quoteName("#__meter_info_server") );
	$query->where( $db->quoteName('location_id')." = ".$db->quote(1) );
	$query->order('meter_address ASC');
	$db->setQuery($query);
	$Inforows = $db->loadAssocList();
        
	$met = 0;
	$count_Mvalue = 0; //for check Array meter_address is empty
	unset($Meter);
	unset($MeterValue);
	unset($meter_address);
    foreach($Inforows AS $InfoVaule){
		$meter_address[$met] = $InfoVaule['meter_address']; 
    $met++;
    }
	
	//$MeterValue[$met] = trim(JRequest::getVar("$Meter[$met]", '-1'));
	    //echo "<br>$Meter[$met] : $MeterValue[$met]";
		///$count_Mvalue = $count_Mvalue + $MeterValue[$met] + 1;  //if $count_Mvalue = 0 Array meter_address is empty

	   // if($MeterValue[$met]=="1"){
		   // $meter_address[$met] = $InfoVaule['meter_address'];
	   // }  
	
	//var_dump($meter_address);
	
	if($count_Mvalue == "0"){ // while all meter none cheched
		$meter_address[0] = '01';
	}
	
	echo "	<br>lastRowIndex = chartData.addRows([ <br>";
	
	
		$from_datetime = date('Y-m-d H:i:s', ( time() - 5*60) ); 
		
		//$firs_s = 0;
		unset($format_datetime);
		unset($phase1_apparent_power);
		unset($phase2_apparent_power);
		unset($phase3_apparent_power);
		unset($count_time);
		
		for($s = 0; $s < $met; $s++){
			// read electrical status
			$db = JFactory::getDbo();
			$query = $db->getQuery(true);
			$query->select( $db->quoteName(array('electrical_id', 'location_id', 'meter_address', 'datetime', 'phase1_apparent_power',  'phase2_apparent_power',  'phase3_apparent_power') ) );
			//$query->select('*');   
			$query->from( $db->quoteName('#__electrical') );
			$query->where( 
			            $db->quoteName('location_id')." = ".$db->quote($location_id) .
                        " AND `meter_address` = " . $db->quote($meter_address[$s]) . 					
				        " AND `datetime` >= " . $db->quote($from_datetime) 
					);
			$query->order('datetime DESC');
			$db->setQuery($query,0,180);
			$rows = $db->loadAssocList();

			sort($rows);


			//$firsttime = 0;
			$t = 0; //for get every $s loop time value of format_datetime
			foreach ($rows as $row){
				    $phase1_apparent_power[$s."_".$t] = $row['phase1_apparent_power'];
				    $phase2_apparent_power[$s."_".$t] = $row['phase2_apparent_power'];
				    $phase3_apparent_power[$s."_".$t] = $row['phase3_apparent_power'];
					$datetime = new DateTime($row['datetime']);
				    $format_datetime[$s."_".$t] = $datetime->format('Y,m-1,d,H,i,s'); // need to reduce month by 1 as JS month starts from 
				
			    $t++;	
			}// for each
			$count_time[$s] = $t ;
            //var_dump($count_time);
	    }//for($s)
		
	    
        for ($s = 0; $s < $met; $s++){
			
			$ArrA = 0;
			for($t = 0; $t <$count_time[$s]; $t++){
				if (!$ArrA) { $ArrA = 1;}
			    else {echo ",";}
				if(sizeof($meter_address) == 1){
		            echo "<br>[ new Date(".$format_datetime[$s."_".$t]."),".$phase1_apparent_power[$s."_".$t].",".$phase2_apparent_power[$s."_".$t].", ".$phase3_apparent_power[$s."_".$t]." ]";
				}else{
					echo "<br>[ new Date(".$format_datetime[$s."_".$t]."),".$phase1_apparent_power[$s."_".$t].",".$phase2_apparent_power[$s."_".$t].", ".$phase3_apparent_power[$s."_".$t].", ";
					
					
					$ArrB = 0;
					for($i = 1; $i < $met; $i++){
						if (!$ArrB) { $ArrB = 1;}
			            else {echo ",";}
						echo $phase1_apparent_power[$i."_".$t].",".$phase2_apparent_power[$i."_".$t].", ".$phase3_apparent_power[$i."_".$t];	 
					}
					
					echo "]";
				}//if
			}//for($t)
				
		}//for($s)	
		
	echo " ]);";
	
?>
