<?php defined('_JEXEC') or die;

/**
 *
 * File       mod_chart_data.php
 */

// Include the helper.
require_once __DIR__ . '/helper.php';

require(JModuleHelper::getLayoutPath('mod_chart','default'));