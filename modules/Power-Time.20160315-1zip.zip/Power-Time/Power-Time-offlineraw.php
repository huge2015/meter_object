﻿
<?php
$js = JURI::base().'modules/mod_voltage_time/js/jsapi.js';  
$document = JFactory::getDocument($js);  
$document->addScript($js); 

$zh_CN = JURI::base().'modules/mod_voltage_time/js/format+zh_CN,default+zh_CN,ui+zh_CN,corechart+zh_CN.I.js';  
$document2 = JFactory::getDocument($zh_CN);  
$document2->addScript($zh_CN); 

$corechart = JURI::base().'modules/mod_voltage_time/js/corechart.js';  
$document3 = JFactory::getDocument($corechart);  
$document3->addScript($corechart);

$jq = JURI::base().'modules/mod_voltage_time/js/jquery-1.9.1.js';  
$document4 = JFactory::getDocument($jq);  
$document4->addScript($jq); 
?>

<html>
  <head>
    <!--<script type="text/javascript" src="https://www.google.com/jsapi"></script>-->
    <!--<script type="text/javascript" src="coreChart.js"></script> -->
   <!--script type="text/javascript" src="jsapi.js"></script> 
   <script src="js/corechart.js" type="text/javascript"></script>
   <link href="js/ui+zh_CN.css" type="text/css" rel="stylesheet">
   <script src="js/format+zh_CN,default+zh_CN,ui+zh_CN,corechart+zh_CN.I.js" type="text/javascript"></script>
  <link href="js/tooltip.css" rel="stylesheet" type="text/css"-->
    <script type="text/javascript">
      google.load("visualization", "1", {packages:["corechart"]});
      google.setOnLoadCallback(drawChart);
      function drawChart() {
        var chartData = new google.visualization.DataTable();
		
        chartData.addColumn('string', 'Task');
        chartData.addColumn('number', 'phase1_voltage');
		chartData.addColumn('number', 'phase2_voltage');
		chartData.addColumn('number', 'phase3_voltage');
		
		/*
        chartData.addRows([
          ['Work',    6, 5, 8],
          ['Eat',      2, 3, 4],
          ['Commute',  3, 2, 5],
          ['Watch TV', 4, 3, 9],
          ['Sleep',    7, 9, 20]
        ]);
        */
		
		'<?php
			// read electrical status
			$db = JFactory::getDbo();
			$query = $db->getQuery(true);
			//$query->select( $db->quoteName(array('electrical_id', 'location_id', 'datetime', 'phase1_voltage',
			   //'phase1_voltage', 'phase1_current', 'phase1_frequency') ) );
			$query->select('*');   
			$query->from( $db->quoteName('joomla3_electrical') );
			$from_datetime = date('Y-m-d H:i:s', ( time() - 5*60) ); 
			$query->where( $db->quoteName('location_id')." = ".$db->quote(1)  . " AND datetime >= '$from_datetime'  " );
			$query->order('datetime DESC');
			$db->setQuery($query,0,180);
			$rows = $db->loadAssocList();

			sort($rows);

			echo "	lastRowIndex = chartData.addRows([
";
			$firsttime = 0;
			foreach ($rows as $row){
				if (!$firsttime) { $firsttime = 1;}
				else {echo ",
";}
				$phase1_voltage = $row['phase1_voltage'];
				$phase2_voltage = $row['phase2_voltage'];
				$phase3_voltage = $row['phase3_voltage'];
				//$datetime = new DateTime($row['datetime']);
				$format_datetime = $row['datetime'];//$datetime->format('Y,m-1,d,H,i,s'); // need to reduce month by 1 as JS month starts from 0
				echo "[$format_datetime,$phase1_voltage ,$phase2_voltage ,$phase3_voltage ]";
			}// for each
		echo "
]);";
        ?>'
		
        var options = {
          width: 650, height: 400,
          title: 'My Daily Activities'
        };

        var chart = new google.visualization.LineChart(document.getElementById('chart_div'));
        chart.draw(chartData, options);
      }
    </script>
  </head>
  <body>
    <div id="chart_div"></div>
  </body>
</html>

