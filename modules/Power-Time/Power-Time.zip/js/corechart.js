if (window['google'] != undefined && window['google']['loader'] != undefined) {
if (!window['google']['visualization']) {
window['google']['visualization'] = {};
//google.visualization.Version = '1.0';
//google.visualization.JSHash = 'dee027d0b48a2e0a0a0375d00d7dd635';
//google.visualization.LoadArgs = 'file\75visualization\46v\0751\46packages\75corechart';
}
//google.loader.writeLoadTag("css", google.loader.ServiceBase + "/api/visualization/1.0/dee027d0b48a2e0a0a0375d00d7dd635/ui+zh_CN.css", false);
//google.loader.writeLoadTag("script", google.loader.ServiceBase + "/api/visualization/1.0/dee027d0b48a2e0a0a0375d00d7dd635/format+zh_CN,default+zh_CN,ui+zh_CN,corechart+zh_CN.I.js", false);
}
