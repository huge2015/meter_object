﻿
<?php
$js = JURI::base().'modules/mod_voltage_time/js/api.js';  
$document = JFactory::getDocument($js);  
$document->addScript($js); 

$jq = JURI::base().'modules/mod_voltage_time/js/jquery-1.9.1.js';  
$document = JFactory::getDocument($jsq);  
$document->addScript($jq); 
?>

<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <!--Load the AJAX API-->
    <script type="text/javascript" src="api.js"></script>
    <script type="text/javascript">
     chart = null; // global variable
	chartData = null; // global variable
	chartOptions = null; // global variable
	dataToLoad = ''; // global variable
	chartCol = []; //global variable
	chartCol[0] = {'db_col_name': 'datetime', 'chart_data_type' : 'datetime', 'chart_label' : 'Date Time' };
	datetimeColumnIndex = 0; // global variable
	chartCol[1] = {'db_col_name': 'phase1_voltage', 'chart_data_type' : 'number', 'chart_label' : 'Phase 1 Voltage'};
	chartCol[2] = {'db_col_name': 'phase2_voltage', 'chart_data_type' : 'number', 'chart_label' : 'Phase 2 Voltage'};
	chartCol[3] = {'db_col_name': 'phase3_voltage', 'chart_data_type' : 'number', 'chart_label' : 'Phase 3 Voltage'};
	vChartAxisMinValue = 0; // global
	vChartAxisMaxValue = 260; // global

	dbColumns = ''; //global variable
	var first_time = 1;
	for (var k = 0; k < chartCol.length; k++){
		if (first_time) { first_time = 0;} else { dbColumns += ',';}
		dbColumns = dbColumns + chartCol[k]['db_col_name'];
	} // for k

	dbTable = 'electrical'; // global variable
	lastRowIndex = 0; // global
	timeRefresh = 15000; // global, refreshes every 15 s
	refreshPeriod = '1-i'; // global, the case to call in changeHAxis
	removeTime = 180000; // global, time in seconds before current time to remove the data
	
	
      // Load the Visualization API and the piechart package.
      google.load('visualization', '1.0', {'packages':['corechart']});
 
      // Set a callback to run when the Google Visualization API is loaded.
      google.setOnLoadCallback(drawChart);
 
      // Callback that creates and populates a data table,
      // instantiates the pie chart, passes in the data and
      // draws it.
      function drawChart() {
 
        // Create the data table.
        var chartData = new google.visualization.DataTable();
        chartData.addColumn('string', 'Topping');
        //chartData.addColumn('number', 'Slices');
		//var chartData = new google.visualization.DataTable(); 
		//chartData.addColumn('Datetime', 'Time');
		chartData.addColumn('number', 'Voltage-1');
        chartData.addColumn('number', 'Voltage-2');
		chartData.addColumn('number', 'Voltage-3');
        
var table = dbTable;
		var location_id = '1';
		var meters = '1';
		var columns = dbColumns;
		var from_datetime_string = (1).minutes().ago().toString('yyyy-MM-dd HH:mm:ss');
		var to_datetime_string = Date.now().toString('yyyy-MM-dd HH:mm:ss');
		var num_records = 60;
		var data_interval = '1-s';

		// getChartDataToDataToLoad(table, location_id, meters, columns, from_datetime_string, to_datetime_string, num_records, data_interval);

		// setTimeout( loadDataToChart('new'), 15000);

<?php
			// read electrical status
			$db = JFactory::getDbo();
			$query = $db->getQuery(true);
			//$query->select( $db->quoteName(array('electrical_id', 'location_id', 'datetime', 'phase1_voltage',
			   //'phase1_voltage', 'phase1_current', 'phase1_frequency') ) );
			$query->select('*');   
			$query->from( $db->quoteName('y3u_electrical') );
			$from_datetime = date('Y-m-d H:i:s', ( time() - 5*60) ); 
			$query->where( $db->quoteName('location_id')." = ".$db->quote(1)  . " AND 'datetime' >= '$from_datetime'  " );
			$query->order('datetime DESC');
			$db->setQuery($query,0,180);
			$rows = $db->loadAssocList();

			sort($rows);

			echo "	lastRowIndex = chartData.addRows(
";
			$firsttime = 0;
			foreach ($rows as $row){
				if (!$firsttime) { $firsttime = 1;}
				else {echo ",
";}
				$phase1_voltage = $row['phase1_voltage'];
				$phase2_voltage = $row['phase2_voltage'];
				$phase3_voltage = $row['phase3_voltage'];
				//$datetime = new DateTime($row['datetime']);
				$format_datetime = $row['datetime'];//$datetime->format('Y,m-1,d,H,i,s'); // need to reduce month by 1 as JS month starts from 0
				echo "[$format_datetime,$phase1_voltage ,$phase2_voltage ,$phase3_voltage ]";
			}// for each
		echo "
);";
?>

        
 
        options = {title: 'Company Performance - 折线图' };
        chart = new google.visualization.LineChart(document.getElementById('chart_div'));
        chart.draw(chartData, options);
 
        
 
	  }   
 
        
    
    </script>
  </head>
 
  <body>
    
          <div id="chart_div"></div>
 <?php       sort($rows);

			echo "	chartData = google.visualization.arrayToDataTable([
			['Time', 'Voltage1', 'Voltage2', 'Voltage3'],
";
			$firsttime = 0;
			foreach ($rows as $row){
				if (!$firsttime) { $firsttime = 1;}
				else {echo ",
";}
				$phase1_voltage = $row['phase1_voltage'];
				$phase2_voltage = $row['phase2_voltage'];
				$phase3_voltage = $row['phase3_voltage'];
				//$datetime = new DateTime($row['datetime']);
				$format_datetime = $row['datetime']; //$datetime->format('Y,m-1,d,H,i,s'); // need to reduce month by 1 as JS month starts from 0
				echo "[ $format_datetime,$phase1_voltage ,$phase2_voltage ,$phase3_voltage ]";
			}// for each
		echo "
]);";	
?>
	<div id="time_setting">
	Time Frame
	<select name='time_frame' onChange="javascript:changeHAxis(this.value);">
		<option value="5-y new">5 years</option>
		<option value="2-y new">2 years</option>
		<option value="1-y new">Year</option>
		<option value="1-q new">Quarter</option>
		<option value="1-m new">Month</option>
		<option value="1-w new">Week</option>
		<option value="1-d new">Day</option>
		<option value="1-h new">Hour</option>
		<option value="1-i new" selected>Minute</option>
	</select> 

	<input type=radio name=live_data value='1' checked>Live</input>
	<input type=radio name=live_data value='0'>Historical</input>

</div>
  </body>
</html>

