﻿
<?php
$js = JURI::base().'modules/mod_voltage_time/js/jsapi.js';  
$document = JFactory::getDocument($js);  
$document->addScript($js); 

$zh_CN = JURI::base().'modules/mod_voltage_time/js/format+zh_CN,default+zh_CN,ui+zh_CN,corechart+zh_CN.I.js';  
$document2 = JFactory::getDocument($zh_CN);  
$document2->addScript($zh_CN); 

$corechart = JURI::base().'modules/mod_voltage_time/js/corechart.js';  
$document3 = JFactory::getDocument($corechart);  
$document3->addScript($corechart);

$jq = JURI::base().'modules/mod_voltage_time/js/jquery-1.9.1.js';  
$document4 = JFactory::getDocument($jsq);  
$document4->addScript($jq); 
?>

<html>
  <head>
    <!--<script type="text/javascript" src="https://www.google.com/jsapi"></script>-->
    <!--<script type="text/javascript" src="coreChart.js"></script> -->
   <!--script type="text/javascript" src="jsapi.js"></script> 
   <script src="js/corechart.js" type="text/javascript"></script>
   <link href="js/ui+zh_CN.css" type="text/css" rel="stylesheet">
   <script src="js/format+zh_CN,default+zh_CN,ui+zh_CN,corechart+zh_CN.I.js" type="text/javascript"></script>
  <link href="js/tooltip.css" rel="stylesheet" type="text/css"-->
    <script type="text/javascript">
      google.load("visualization", "1", {packages:["corechart"]});
      google.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = new google.visualization.DataTable();
		
        data.addColumn('string', 'Task');
        data.addColumn('number', 'A');
		data.addColumn('number', 'B');
		data.addColumn('number', 'C');
		data.addColumn('number', 'D');
		data.addColumn('number', 'E');
		data.addColumn('number', 'F');
		
		
        data.addRows([
          ['Work',    6, 5, 8, 2, 3, 4],
          ['Eat',      2, 3, 4,  3, 2, 5],
          ['Commute',  3, 2, 5, 7, 9, 20],
          ['Watch TV', 4, 3, 9, 4, 3, 9],
          ['Sleep',    7, 9, 20, 4,  3, 2]
        ]);

        var options = {
          width: 650, height: 400,
          title: 'My Daily Activities'
        };

        var chart = new google.visualization.LineChart(document.getElementById('chart_div'));
        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <div id="chart_div"></div>
  </body>
</html>

